--
--LOAD DATA
--

--Delete all tables in reverse order to clear references
DELETE FROM Permission;
DELETE FROM D_D_Connection;
DELETE FROM P_D_Connection;
DELETE FROM Payment;
DELETE FROM Medical_Record;
DELETE FROM Appointments;
DELETE FROM HCP_Account;
DELETE FROM Patient_Account;
DELETE FROM Messages;
DELETE FROM Accounts;
DELETE FROM Refers;
DELETE FROM Is_In;
DELETE FROM Groups;
DELETE FROM Connections;


--Copy Account Information
COPY Accounts(
	account_id,
	email,
	password
)
FROM '/home/matteo/Desktop/salute/database/data/accounts.txt'
WITH DELIMITER ';';


--Copy Messages Information
COPY Messages(
	message_id,
	sender_id,
	receiver_id,
	sender_kept,
	receiver_kept,
	subject,
	content,
	datetime
)
FROM '/home/matteo/Desktop/salute/database/data/messages.txt'
WITH DELIMITER ';';


--Copy Patient_Account Information
COPY Patient_Account(
	account_id,
	--patient_id,
	first_name,
	last_name,
	middle_name,
	ssn,
	dob,
	sex,
	tel_number,
	fax_number,
	address,
	picture_name
)
FROM '/home/matteo/Desktop/salute/database/data/patient_account.txt'
WITH DELIMITER ';';


--Copy HCP_Account Information
COPY HCP_Account(
	account_id,
	--hcp_id,
	first_name,
	last_name,
	middle_name,
	ssn,
	dob,
	sex,
	tel_number,
	fax_number,
	specialization,
	org_name,
	address,
	picture_name
)
FROM '/home/matteo/Desktop/salute/database/data/hcp_account.txt'
WITH DELIMITER ';';


--Copy Appointment Information
COPY Appointments(
	appointment_id,
	patient_id,
	hcp_id,
	descryption,
	date_time,
	approved
)
FROM '/home/matteo/Desktop/salute/database/data/appointments.txt'
WITH DELIMITER ';';

--Copy Medical_Record Information
COPY Medical_Record(
	patient_id,
	account_id, 
	issue,
	suplementary_info,
	file_name,
	description
)
FROM '/home/matteo/Desktop/salute/database/data/medical_records.txt'
WITH DELIMITER ';';


--Copy Payment Information
Copy Payment(
	bill_id,
	patient_id,
	hcp_id,
	amount,
	descryption,
	due_date,
	cleared,
	hcp_kept,
	patient_kept,
	creation_date
)
FROM '/home/matteo/Desktop/salute/database/data/payment.txt'
WITH DELIMITER ';';


--Copy P_D_Connection Information
COPY P_D_Connection(
	patient_id,
	hcp_id,
	accepted,
	date_connected
)
FROM '/home/matteo/Desktop/salute/database/data/p_d_connection.txt'
WITH DELIMITER ';';


--Copy D_D_Connection Information
COPY D_D_Connection(
	requester_id,
	accepter_id,
	accepted,
	date_connected
)
FROM '/home/matteo/Desktop/salute/database/data/d_d_connection.txt'
WITH DELIMITER ';';


--Copy Permission Information
COPY Permission(
	permission_id,
	medical_rec_id,
	account_id,
	date_created
)
FROM '/home/matteo/Desktop/salute/database/data/permissions.txt'
WITH DELIMITER ';';

--Copy Refers Information
COPY refers(
	refering_id,
	is_refered_id,
	patient_id
)
FROM '/home/matteo/Desktop/salute/database/data/refers.txt'
WITH DELIMITER ';';

--Copy Groups Information
COPY groups(
	group_id,
	account_id,
	name,
	description,
	public_private,
	group_type
)
FROM '/home/matteo/Desktop/salute/database/data/groups.txt'
WITH DELIMITER ';';

--COPY Is_In Information
COPY is_in(
	account_id,
	group_id,
	permissions
)
FROM '/home/matteo/Desktop/salute/database/data/is_in.txt'
WITH DELIMITER ';';

--Copy Connections Information
COPY connections(
    sender_id,
    receiver_id,
    accepted,
    date_connected
)
FROM '/home/matteo/Desktop/salute/database/data/connections.txt'
WITH DELIMITER ';';
